from django.apps import AppConfig


class Practice1Config(AppConfig):
    name = 'practice1'
